
# A very simple Flask Hello World app for you to get started with...

from application import app

from application import routes